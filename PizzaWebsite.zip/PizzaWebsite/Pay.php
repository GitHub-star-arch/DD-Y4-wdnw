<!DOCTYPE html>
<html>
  <head>
    <title>Pizza Website</title>
    <link rel="stylesheet" href="Extra/PageDesignExtra.css" />
  </head>
  <body>
    <h1 style="margin-left: 450px">Please Input the Information Here!</h1>
    <img
      src="Pictures/M.png"
      alt="M"
      width="100"
      height="100"
      style="margin-left: 650px"
    />
    <br />

    <form style="margin-left: 600px">
      First name:<br />
      <input
        type="text"
        name="first_nam"
        value="Please Enter First Name Here"
        style="width: 210px"
      /><br />
      Last name:<br />
      <input
        type="text"
        name="last_name"
        value="Please Enter Last Name Here"
        style="width: 210px"
      /><br />
      Pizza:<br />
      <input
        type="text"
        name="pizza"
        value="Please Enter The Pizza Type Here"
        style="width: 210px"
      /><br />
      Address:<br />
      <input
        type="text"
        name="address"
        value="Please Enter Address Here"
        style="width: 210px"
      /><br />
      Number:<br />
      <input
        type="text"
        name="phonenumber"
        value="Please Enter Phone Number Here"
        style="width: 210px"
      /><br /><br />
      <input
        style="
          color: crimson;
          background-color: black;
          width: 100px;
          height: 50px;
          margin-left: 50px;
        "
        type="submit"
        value="Send"
      />
    </form>
  </body>
</html>
<?php
$a="localhost";
$b="root";
$c="";
$d="test";


$con=mysqli_connect($a,$b,$c,$d);
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
    else
{
    echo "Successfully connected";
}

$first_nam =$_REQUEST['first_nam'];
$last_name = $_REQUEST['last_name'];
$type =  $_REQUEST['pizza'];
$address = $_REQUEST['address'];
$phonenumber = $_REQUEST['phonenumber'];

$sql = "INSERT INTO pizza_information("First_Name","Last_Name","Pizza","Address","Number")
VALUES('$first_nam','$last_name','$type','$address','$phonenumber')";
       
       
if(mysqli_query($con, $sql)){
    echo "<h3>data stored in a database successfully." 
        . " Please browse your localhost php my admin" 
        . " to view the updated data</h3>"; 
  
    echo nl2br("\n$first_name\n $last_name\n "
        . "$type\n $address\n $phonenumber");
} else{
    echo "ERROR: Hush! Sorry $sql. " 
        . mysqli_error($con);
}
          
mysqli_close($con);

exit();
?>

